﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;


namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        public MainWindow()
        {
            // tolist();

            InitializeComponent();
            LoadData();
        }
        private string connectionString = "Server=HOME-PC4\\SQLEXPRESS;Database=TestBase;Trusted_Connection=True";
        private int? selectedId = null;
        private void DataGrid_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            if (dataGrid.SelectedItem is DataRowView rowView)
            {
                selectedId = Convert.ToInt32(rowView["ID"]);
            }
            else
            {
                selectedId = null;
            }
        }
        private void LoadData()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    SqlCommand command = new SqlCommand("SELECT * FROM Product_type", connection);
                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);
                    dataGrid.ItemsSource = dataTable.DefaultView;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка: " + ex.Message);
                }
            }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            if (selectedId.HasValue)
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    try
                    {
                        connection.Open();
                        SqlCommand command = new SqlCommand("DELETE FROM Product_type WHERE ID = @ID", connection); // Замените "YourTable" и "Id" на ваши значения
                        command.Parameters.AddWithValue("@Id", selectedId.Value);
                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Запись успешно удалена.");
                            LoadData(); // Обновляем данные в DataGrid
                        }
                        else
                        {
                            MessageBox.Show("Не удалось удалить запись.");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Ошибка: " + ex.Message);
                    }
                }
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите запись для удаления.");
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            vivod vivod = new vivod();
            vivod.Show();
            this.Close();

        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            using (var db = new TestBaseEntities())
            {
                var dovsd = new Product_type();
                dovsd.Название = nasv.Text;
                dovsd.Коэффициент_типа_продукции = Convert.ToDouble(kef.Text);
                try
                {
                    db.Product_type.Add(dovsd);
                    db.SaveChanges();
                    MessageBox.Show("успешно");
                    LoadData();
                }
                catch (Exception ex) { MessageBox.Show(ex.Message); }
            }
            /* void tolist()
    {

    var listpartners = new List<Partner>();
    foreach (var a in db.Partners.ToList())
    {

    var sum = db.Partners_product.Where(y => a.ID == y.ID_Partner).Sum(x => x.Количество_продукции);
    string sale = "0%";
    if (sum < 10000)
    {
    sale = "0%";
    }
    if (sum <= 10000 && sum < 50000)
    {
    sale = "5%";
    }
    if (sum <= 50000 && sum < 300000)
    {
    sale = "10%";
    }
    if (sum >= 300000)
    {
    sale = "15%";
    }
    listpartners.Add(new Partner { ID = a.ID, Директор = a.Директор, Наименование_партнера = a.Наименование_партнера, Рейтинг = "Рейтинг: " + a.Рейтинг, Телефон_партнера = a.Телефон_партнера, Тип_партнера = a.Тип_партнера, Скидка = sale });
    }

    listPartner.ItemsSource = listpartners;
    }*/
        }
    }
}
