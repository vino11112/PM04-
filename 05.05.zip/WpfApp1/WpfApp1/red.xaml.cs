﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для red.xaml
    /// </summary>
    public partial class red : Window
    {
        public red()
        {
            InitializeComponent();
            LoadData();
        }
        private string connectionString = "Server=HOME-PC4\\SQLEXPRESS;Database=TestBase;Trusted_Connection=True";

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            int id;
            if (int.TryParse(idd.Text, out id))
            {
                string newValue = kef.Text;
                Update(id, newValue);

            }

            else {
                MessageBox.Show("Введите коректный id");
                }
        }
        private void Update(int id, string newValue)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string quert = "update Product_type SET [Коэффициент типа продукции]= @newValue where id=@id";
                SqlCommand command = new SqlCommand(quert, connection);
                command.Parameters.AddWithValue("@newValue", newValue);
                command.Parameters.AddWithValue("@id", id);
                try
                {
                    connection.Open();
                    int rowsAffected = command.ExecuteNonQuery();
                    if (rowsAffected > 0) { LoadData();
                        MessageBox.Show("норм");
                    }
                    else
                        MessageBox.Show("запись не найдена");

                }
                catch (Exception ex) {
                    MessageBox.Show(ex.Message);
                }
            }
        }
        private void LoadData()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    SqlCommand command = new SqlCommand("SELECT * FROM Product_type", connection);
                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);
                    datagrid.ItemsSource = dataTable.DefaultView;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка: " + ex.Message);
                }
            }
        }


    } }
