﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;


namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private SqlDataAdapter adapter;
        public MainWindow()
        {
            // tolist();

            InitializeComponent();
            LoadData();

        }
        private string connectionString = "Server=HOME-PC4\\SQLEXPRESS;Database=TestBase;Trusted_Connection=True";
        private int? selectedId = null;
        private void DataGrid_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            if (dataGrid.SelectedItem is DataRowView rowView)
            {
                selectedId = Convert.ToInt32(rowView["ID"]);
            }
            else
            {
                selectedId = null;
            }
        }
        private void LoadData()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    SqlCommand command = new SqlCommand("SELECT * FROM Product_type", connection);
                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);
                    dataGrid.ItemsSource = dataTable.DefaultView;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка: " + ex.Message);
                }
            }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            if (selectedId.HasValue)
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    try
                    {
                        connection.Open();
                        SqlCommand command = new SqlCommand("DELETE FROM Product_type WHERE ID = @ID", connection); // Замените "YourTable" и "Id" на ваши значения
                        command.Parameters.AddWithValue("@Id", selectedId.Value);
                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Запись успешно удалена.");
                            LoadData(); // Обновляем данные в DataGrid
                        }
                        else
                        {
                            MessageBox.Show("Не удалось удалить запись.");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Ошибка: " + ex.Message);
                    }
                }
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите запись для удаления.");
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            vivod vivod = new vivod();
            vivod.Show();
            this.Close();

        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            using (var db = new TestBaseEntities())
            {
                var dovsd = new Product_type();
                dovsd.Название = nasv.Text;
                dovsd.Коэффициент_типа_продукции = Convert.ToDouble(kef.Text);
                try
                {
                    db.Product_type.Add(dovsd);
                    db.SaveChanges();
                    MessageBox.Show("успешно");
                    LoadData();
                }
                catch (Exception ex) { MessageBox.Show(ex.Message); }
            }
        } 
        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
           red red = new red();
            red.Show();
            this.Close();
        }
    }
}
